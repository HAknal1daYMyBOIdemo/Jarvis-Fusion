# Validation

- Eleven unittest integration checks pass in a clean Python 3.12 virtual environment.
- Real pinned Javis recall, graph-link parsing, persistence across index reopening, and deletion exercised.
- Provider switching preserves notes and chat history; both actual OpenJarvis adapters tested with mocked HTTP responses.
- Catalog endpoint returns 21 upstream entries; download streaming contract tested with a mocked upstream iterator.
- Chromium browser checks: note creation/editing, graph search, provider toggle, catalog capability filtering,
  and desktop (1440 px) / mobile (390 px) layout. No JavaScript runtime errors or mobile horizontal overflow.
- Windows launcher, real model downloads, actual Ollama generation, and billable OpenAI requests remain unverified.
- Browser screenshots use explicitly created test notes, not imported user memories.

Run: python -m unittest discover -s tests -v
Browser smoke test is environment-specific; inspect paths and use disposable server data before running.


Voice additions:
- Local speech status, explicit setup, audio format/size boundaries, CSRF, missing installation,
  unclear audio and the actual Javis transcriber call contract covered by unit tests.
- Headless Chromium uses a real MediaRecorder/getUserMedia pipeline with a synthetic WAV fixture.
  Transcript/model services and device voice synthesis are mocked. Checks cover voice activity
  segmentation, mic pause during playback, automatic resume, stop/release, spoken stop and denial.
- Desktop/mobile Jarvis home inspected visually. Existing memory/catalog browser tests still pass.
- Windows device voices, real Whisper recognition, actual spoken output and native microphone
  quality/latency remain unverified. No speech model was downloaded in the build environment.
