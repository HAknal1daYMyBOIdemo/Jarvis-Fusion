@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  echo Install Python 3.12 from python.org with the Python launcher enabled, then run this again.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  py -3.12 -m venv .venv
  if errorlevel 1 goto :failed
)
if not exist ".venv\fusion-installed" (
  .venv\Scripts\python.exe -m pip install -r requirements.txt
  if errorlevel 1 goto :failed
  echo installed> .venv\fusion-installed
)
.venv\Scripts\python.exe app.py
if errorlevel 1 goto :failed
exit /b 0
:failed
echo.
echo Fusion could not start. Review the error above. Requires Python 3.12 and internet for first setup.
pause
exit /b 1
