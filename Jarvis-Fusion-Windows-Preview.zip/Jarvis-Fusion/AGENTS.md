# Fusion development

Read READ-ME-FIRST.md and DECISIONS.md. Preserve upstream licenses and commit pins.
Keep data out of release archives. Keep the server loopback-only. Test provider switching,
recall, persistence, graph parsing and request boundaries. Do not claim native Windows
verification unless actually run on Windows. Do not modify vendored code silently.
