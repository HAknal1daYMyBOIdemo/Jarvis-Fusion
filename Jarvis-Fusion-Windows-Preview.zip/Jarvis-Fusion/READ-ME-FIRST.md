# Jarvis Fusion — Windows preview

A working integration prototype: OpenJarvis inference engines, Javis OS memory retrieval,
Javis OS's linked-note parser and Ollama model catalog/downloader, and a new local UI.
This is not the complete OpenJarvis agent runtime or the complete Javis OS dashboard.

## Start on Windows

1. Extract this entire folder to a writable location, such as Documents\Jarvis-Fusion.
2. Install **Python 3.12** with the Python launcher from https://www.python.org/downloads/windows/.
3. For local models, install and start **Ollama for Windows** from https://ollama.com/download/windows.
4. Double-click **Start-Fusion.cmd**. First launch installs Python packages. Keep its terminal open.
5. Your browser opens **http://127.0.0.1:8765**. In Models, download a model and select “Use this model”.
   Choose a model that fits your machine; upstream download sizes are not RAM requirements.
6. Add memories with “New memory”. Link them with `[[Exact note title]]` to create graph edges.
7. To switch to OpenAI, open Connect, enter an API key, select OpenAI in chat and a model ID
   available to your account, then enable cloud context. Recent history and retrieved memories
   are sent to OpenAI on each message. API billing is separate from a ChatGPT subscription.

The 21-entry catalog comes from the pinned Javis OS release, not a live inventory of all Ollama
models. Download availability depends on the registry. Models are downloaded only when clicked.
For tags outside the catalog, use `ollama pull <tag>` and click Refresh installed.

## What persists

- `data/brain/memory/*.md`: readable Markdown memories (source of truth).
- `data/index/memory_index.db`: rebuildable Javis search index.
- `data/conversations.db`: shared conversation across model switches and restarts.
- API keys: process memory only, cleared when the server exits. An OPENAI_API_KEY environment
  variable is also supported. The browser never stores the key in localStorage.
- Model selection: local browser storage. Ollama manages model files separately.

Back up `data/` after closing Fusion. Deleting a memory does not erase earlier chat transcripts
or data already sent to a provider. Clear conversation separately if needed. Memory is plaintext
on your computer; use Windows account/disk protection as appropriate.

## Prototype behavior and limits

- Real Javis `MemoryIndex` retrieves context for both providers. The last 12 messages and up to
  6 bounded memory passages are included; this is not unlimited context or perfect recall.
- OpenJarvis `OllamaEngine` and `CloudEngine` perform inference. No simulated model replies.
- Explicit “Remember”/New memory writes only. Automatic extraction/consolidation, background
  agents, full tool execution and other providers are not enabled in this preview.
- Graph edges use Javis's wikilink parser. The Fusion graph renderer is new; it is not the full
  Javis graph UI. Categories arrange nodes; only explicit links produce edges.
- Renaming a note requires updating links to that title. The UI manages its own UUID-named
  notes; importing arbitrary existing Javis vaults is not implemented.
- Downloads stream progress through Javis's real Ollama downloader. Stop closes the request;
  Ollama may retain partial files. No model binaries ship in this archive.
- Local requests are restricted to loopback hosts, mutations require a session token and the
  UI loads no external scripts or fonts. Do not expose this development server to a network.
- Windows launcher supplied but not executed on Windows during development. Linux verification
  covers backend integration, browser UI and mocked provider/download contracts. Real Ollama
  generation and OpenAI billing calls require your running Ollama or API credentials.

## Developer checks

`python -m unittest discover -s tests -v`

Run `python app.py` after installing requirements. Override FUSION_DATA_DIR to isolate test data.
Pinned upstream commits are recorded in upstream-lock.json. See vendor licenses and DECISIONS.md.


## Jarvis voice home (0.2 preview)

The default home screen now has an animated teal core inspired by the supplied visual reference.
The Memory and Models pages remain accessible from the left navigation.

1. Use Chrome or Edge on Windows at localhost. Choose a working Ollama or OpenAI model.
2. Open **Voice settings**, then **Install local speech**. This explicitly downloads Javis OS's
   optional offline Whisper module and dependencies (about 1 GB). Progress is a setup status,
   not an exact byte counter. Installation logs live in `data/javis-state/local-ear/install.log`.
3. Select an installed **device-local voice** and click **Test voice**. If none appear, install
   a voice through Windows Settings → Time & language → Speech, then reopen the browser.
4. Click **Enable open mic** and allow microphone access. Ask a question, then pause for about
   1.2 seconds. Questions are limited to roughly 30 seconds per turn. English is selected for
   transcription in this preview.
5. Jarvis transcribes locally, retrieves the shared memory, calls the selected model, speaks
   its reply, then resumes listening. The microphone is paused during transcription/inference
   and speech playback to prevent feedback. **Stop speaking** skips playback and resumes listening.
6. **Microphone on · Turn off**, or saying “Jarvis, stop listening”, releases the audio device. Hiding the browser tab or navigating
   away from Jarvis home also stops the microphone. A fresh page never starts it automatically.

Audio is processed by Javis OS's actual `local_stt` / `offline_ear` worker, not by browser/cloud
speech recognition. Temporary audio files are removed by that worker after transcription. Speech
output uses the browser's device-local speech synthesis voices, not a cloned film voice.
With Ollama, the pipeline is local after setup. With OpenAI, the transcript, recent messages and
retrieved memories go to the OpenAI API when cloud context is enabled; raw mic audio stays local.

This is turn-taking voice chat, not a wake-word/background Windows service or simultaneous
barge-in. Local Whisper loads per request in a separate process; latency depends on CPU and can
be several seconds. The listening animation follows microphone energy; the speaking animation
is stylized because browser speech synthesis exposes no output waveform. Reduced-motion settings
are respected. Native Windows microphone/voice and real Whisper recognition are not yet verified
on a user's machine; browser tests use fixture audio and mocked transcript/model/speech services.
