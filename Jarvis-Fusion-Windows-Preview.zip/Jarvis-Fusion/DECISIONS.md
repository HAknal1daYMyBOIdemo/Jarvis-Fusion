# Integration decisions

1. Windows-native Python 3.12 server plus localhost web interface. No Docker, Node or Rust
   build required for this selected subset. Full OpenJarvis storage has additional native requirements.
2. Model-independent persistence. All provider choices share the same brain and conversation DB.
3. Reuse real Javis OS memory_index, graph_builder.doc_wikilink, ollama_catalog and
   ollama_local.pull_stream. Avoid creating a competing search engine or catalog.
4. Use pinned OpenJarvis OllamaEngine/CloudEngine inference code; a small subclass supplies
   the session-only OpenAI client. This is a focused integration, not a full runtime merge.
5. Single explicit memory writer in Fusion. Automatic extraction is deferred pending review of
   trust, conflict handling and the Javis memory-writing lifecycle.
6. New graph presentation with real explicit links and editable Markdown. This UI does not
   reproduce every feature of the existing Javis dashboard (timelapse, agent overlays, vault import).
7. Cloud context is an explicit user choice. Keys stay in memory. Provider failures do not fabricate
   successful chat replies; failed requests do not append to history.
8. Upstream source subsets are vendored with their original licenses and pinned commit hashes.
   They are unmodified. The app calls them directly. Upgrade only with integration tests.

9. Voice uses the upstream Javis offline-ear installer/transcriber, invoked only on user setup.
   No browser SpeechRecognition or cloud STT fallback. Input is capped to 8 MiB and audio formats.
10. Speech output uses device-local browser voices; the interface does not impersonate the film
    actor's voice. The main screen is a new procedural teal HUD inspired by the user's trailer.
11. Open mic is explicit and turn-taking, with audio activity detection and a silence timeout.
    Capture pauses for processing/playback; shutdown, navigation and hidden tabs release the mic.
    Model calls share the same history and memory path as text chat.
