import math,wave,struct,json
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
wav='/workspace/work/voice-fixture.wav'
with wave.open(wav,'wb') as f:
    f.setparams((1,2,48000,0,'NONE','not compressed'))
    # Repeating voiced tones and silence exercise segmentation, not speech recognition.
    for i in range(48000*5):
        t=i/48000
        value=int(8000*math.sin(2*math.pi*180*t)) if 1<t<2.1 else 0
        f.writeframesraw(struct.pack('<h',value))
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream','--use-file-for-fake-audio-capture='+wav])
    context=browser.new_context(viewport={'width':1440,'height':1000},permissions=['microphone'])
    page=context.new_page()
    page.add_init_script('''
      window.SpeechSynthesisUtterance=class {constructor(text){this.text=text;}dispatchEvent(e){this['on'+e.type]?.(e);}};
      window.testVoice={spoken:0,cancelled:0,stream:null};let t;
      Object.defineProperty(window,'speechSynthesis',{value:{getVoices:()=>[{name:'Test local English voice',voiceURI:'local-test',lang:'en-GB',localService:true}],addEventListener:()=>{},cancel:()=>{clearTimeout(t);testVoice.cancelled++},speak:u=>{testVoice.spoken++;t=setTimeout(()=>u.dispatchEvent(new Event('end')),1400)}}});
      const original=navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
      navigator.mediaDevices.getUserMedia=async c=>{testVoice.stream=await original(c);return testVoice.stream;};
    ''')
    errors=[];calls={'transcribe':0,'chat':0}
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.route('**/api/models',lambda r:r.fulfill(json={'models':['test-local'],'error':''}))
    page.route('**/api/voice/status',lambda r:r.fulfill(json={'installed':True,'model':'small','running':False,'error':''}))
    def transcribe(r):
        assert len(r.request.post_data_buffer)>100
        calls['transcribe']+=1
        r.fulfill(json={'text':'Hello Jarvis, what do you remember?','model':'test'})
    page.route('**/api/voice/transcribe',transcribe)
    def chat(r):
        calls['chat']+=1
        r.fulfill(json={'content':'Your memories are connected across models.','sources':[]})
    page.route('**/api/chat',chat)
    page.goto('http://127.0.0.1:8766')
    expect(page.locator('#home-panel')).to_be_visible()
    expect(page.locator('#model')).to_have_value('test-local')
    assert not calls['transcribe']
    page.screenshot(path='/workspace/work/jarvis-home-preview.png',full_page=True)
    page.locator('#mic-toggle').click()
    expect(page.locator('#mic-toggle')).to_have_attribute('aria-pressed','true')
    expect(page.locator('#home-panel')).to_have_attribute('data-state','speaking',timeout=20000)
    assert calls['transcribe']==1 and calls['chat']==1,calls
    assert page.evaluate('() => testVoice.stream.getAudioTracks().every(t=>!t.enabled)')
    page.screenshot(path='/workspace/work/jarvis-speaking-preview.png',full_page=True)
    try:
        expect(page.locator('#home-panel')).to_have_attribute('data-state','listening',timeout=10000)
    except Exception:
        print('DEBUG',errors,page.evaluate('() => ({spoken:testVoice.spoken,cancelled:testVoice.cancelled})'),calls,flush=True)
        raise
    page.wait_for_function('() => testVoice.stream.getAudioTracks().every(t=>t.enabled)')
    page.locator('#mic-toggle').click()
    assert page.evaluate('() => testVoice.stream.getAudioTracks().every(t=>t.readyState==="ended")')
    expect(page.locator('#mic-toggle')).to_have_attribute('aria-pressed','false')
    snapshot=dict(calls)
    page.wait_for_timeout(5500)
    assert calls==snapshot,(calls,snapshot)
    # Spoken stop is handled locally and never becomes a model question.
    page.unroute('**/api/voice/transcribe')
    page.route('**/api/voice/transcribe',lambda r:r.fulfill(json={'text':'Jarvis, stop listening.','model':'test'}))
    before=calls['chat']
    page.locator('#mic-toggle').click()
    expect(page.locator('#mic-toggle')).to_have_attribute('aria-pressed','true')
    expect(page.locator('#mic-toggle')).to_have_attribute('aria-pressed','false',timeout=20000)
    assert calls['chat']==before
    assert page.evaluate('() => testVoice.stream.getAudioTracks().every(t=>t.readyState==="ended")')
    # Permission failure leaves a visible, recoverable state.
    page.evaluate("() => {navigator.mediaDevices.getUserMedia=async()=>{throw new DOMException('Denied','NotAllowedError')}}")
    page.locator('#mic-toggle').click()
    expect(page.locator('#home-panel')).to_have_attribute('data-state','error')
    expect(page.locator('#voice-status')).to_contain_text('permission was denied')
    page.locator('[data-view=brain]').click()
    expect(page.get_by_role('heading',name='Your memory, connected.')).to_be_visible()
    page.locator('[data-view=home]').click()
    page.set_viewport_size({'width':390,'height':844})
    page.screenshot(path='/workspace/work/jarvis-home-mobile.png',full_page=True)
    assert page.evaluate('() => document.documentElement.scrollWidth<=innerWidth')
    assert not errors,errors
    browser.close()
    print('PASS: home screen; actual browser capture with fixture audio; VAD; transcript/chat pipeline (mocked services); local TTS dispatch (mocked); muted mic during replies; automatic resume; tracks ended on stop; responsive layout; no JS errors.')
