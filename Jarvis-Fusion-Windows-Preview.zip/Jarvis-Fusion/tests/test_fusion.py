import os, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
import sys
sys.path.insert(0,str(ROOT))
_temp=tempfile.TemporaryDirectory()
os.environ['FUSION_DATA_DIR']=_temp.name
import app
from fastapi.testclient import TestClient
from openjarvis.core.types import Message,Role
import httpx

class FusionTests(unittest.TestCase):
    def setUp(self):
        self.client=TestClient(app.app)
        self.headers={'X-Fusion-Token':self.client.get('/api/state').json()['token']}
        for p in app.notes.glob('*.md'): p.unlink()
        app.index.rebuild(app.brain)
        with app.db() as db: db.execute('DELETE FROM messages')
    def note(self,title='Python',body='The user prefers Python for automation scripts.'):
        r=self.client.post('/api/notes',json={'title':title,'body':body,'category':'Preferences'},headers=self.headers)
        self.assertEqual(r.status_code,200,r.text)
        return r.json()['id']
    def test_memory_lifecycle_and_graph(self):
        a=self.note()
        b=self.note('Automation','Build scripts with [[Python]]. Ignore code `[[Not a note]]`.')
        g=self.client.get('/api/graph').json()
        self.assertEqual(len(g['links']),1)
        self.assertEqual({g['links'][0]['source'],g['links'][0]['target']},{a,b})
        self.assertTrue(app.index.retrieve(app.brain,'Python automation').records)
        app.index.close()
        self.assertTrue(app.index.retrieve(app.brain,'Python automation').records)
        for id in [a,b]: self.assertEqual(self.client.delete('/api/notes/'+id,headers=self.headers).status_code,200)
        self.assertEqual(app.index.retrieve(app.brain,'Python automation').records,())
    def test_switch_keeps_memory_and_history(self):
        self.note()
        calls=[]
        class Engine:
            def __init__(self,*a,**k): pass
            def generate(self,messages,**kwargs): calls.append((messages,kwargs));return {'content':'You prefer Python.'}
            def close(self): pass
        app.api_key='test-key'
        with patch.object(app,'OllamaEngine',Engine),patch.object(app,'OpenAIEngine',Engine):
            for provider,model in [('ollama','test-local'),('openai','gpt-4o-mini')]:
                r=self.client.post('/api/chat',headers=self.headers,json={'text':'What language do I prefer for automation?','provider':provider,'model':model,'cloud_context':True})
                self.assertEqual(r.status_code,200,r.text)
                self.assertTrue(r.json()['sources'])
        self.assertEqual(len(app.history()),4)
        self.assertTrue(any('Python' in m.content for m in calls[0][0]))
        self.assertTrue(any(m.role==Role.ASSISTANT for m in calls[1][0]))
        self.assertEqual(len(app.all_notes()),1)
    def test_failed_request_and_cloud_choice(self):
        payload={'text':'Hello','provider':'openai','model':'gpt-4o-mini'}
        self.assertEqual(self.client.post('/api/chat',headers=self.headers,json=payload).status_code,400)
        with patch.object(app,'OllamaEngine',side_effect=RuntimeError('secret-key')):
            payload.update(provider='ollama',model='test')
            r=self.client.post('/api/chat',headers=self.headers,json=payload)
        self.assertEqual(r.status_code,502)
        self.assertNotIn('secret-key',r.text)
        self.assertFalse(app.history())
    def test_request_boundaries(self):
        self.assertEqual(self.client.post('/api/key',json={'key':'secret'}).status_code,403)
        self.assertEqual(self.client.get('/api/state',headers={'Host':'evil.test'}).status_code,400)
        self.assertEqual(self.client.delete('/api/notes/not-an-id',headers=self.headers).status_code,400)
        self.note()
        r=self.client.post('/api/notes',headers=self.headers,json={'title':'Python','body':'Duplicate'})
        self.assertEqual(r.status_code,409)
        self.assertNotIn('test-key',self.client.get('/api/state').text)
    def test_catalog_and_download_contract(self):
        catalog=self.client.get('/api/catalog').json()
        self.assertGreaterEqual(len(catalog['items']),21)
        async def fake(endpoint,model):
            self.assertEqual(endpoint,'http://127.0.0.1:11434')
            yield {'status':'pulling','completed':5,'total':10}
            yield {'status':'success'}
        import ollama_local
        with patch.object(ollama_local,'pull_stream',fake):
            r=self.client.post('/api/pull',headers=self.headers,json={'model':'llama3.2:3b'})
        self.assertEqual(r.status_code,200)
        self.assertIn('success',r.text)
        self.assertEqual(self.client.post('/api/pull',headers=self.headers,json={'model':'bad;command'}).status_code,422)
    def test_real_ollama_engine_http_contract(self):
        def handler(request):
            import json
            body=json.loads(request.content)
            self.assertEqual(body['model'],'test-model')
            return httpx.Response(200,json={'message':{'content':'Actual adapter response'},'done':True,'prompt_eval_count':4,'eval_count':3})
        engine=app.OllamaEngine()
        engine._client.close()
        engine._client=httpx.Client(base_url='http://127.0.0.1:11434',transport=httpx.MockTransport(handler))
        try:
            result=engine.generate([Message(role=Role.USER,content='Hello')],model='test-model')
            self.assertEqual(result['content'],'Actual adapter response')
        finally: engine.close()
    def test_real_openai_engine_http_contract(self):
        import openai,json
        def handler(request):
            body=json.loads(request.content)
            self.assertEqual(body['model'],'gpt-4o-mini')
            return httpx.Response(200,json={'id':'test','object':'chat.completion','created':1,'model':'gpt-4o-mini','choices':[{'index':0,'message':{'role':'assistant','content':'Cloud adapter response'},'finish_reason':'stop'}],'usage':{'prompt_tokens':4,'completion_tokens':3,'total_tokens':7}})
        app.api_key='test'
        engine=app.OpenAIEngine()
        engine._openai_client.close()
        engine._openai_client=openai.OpenAI(api_key='test',http_client=httpx.Client(transport=httpx.MockTransport(handler)))
        try:
            result=engine.generate([Message(role=Role.USER,content='Hello')],model='gpt-4o-mini')
            self.assertEqual(result['content'],'Cloud adapter response')
        finally: engine.close()

if __name__=='__main__': unittest.main()
