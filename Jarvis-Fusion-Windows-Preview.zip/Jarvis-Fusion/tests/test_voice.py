import unittest
from unittest.mock import patch, AsyncMock
import test_fusion
import app, voice_api

class VoiceTests(unittest.TestCase):
    setUp = test_fusion.FusionTests.setUp
    # Only voice-specific tests here; base fixture shares disposable data.
    def test_local_speech_contract(self):
        with patch.object(voice_api.local_stt,'installed',return_value=True), patch.object(voice_api.local_stt,'transcribe',new_callable=AsyncMock) as transcribe:
            transcribe.return_value={'ok':True,'text':'Hello Jarvis','model':'whisper-small (offline)'}
            r=self.client.post('/api/voice/transcribe',content=b'fake audio',headers=self.headers|{'Content-Type':'audio/webm;codecs=opus'})
            self.assertEqual(r.status_code,200,r.text)
            self.assertEqual(r.json()['text'],'Hello Jarvis')
            transcribe.assert_awaited_once_with(b'fake audio','question.webm',lang='en')
    def test_speech_boundaries(self):
        r=self.client.post('/api/voice/install',json={})
        self.assertEqual(r.status_code,403)
        with patch.object(voice_api.local_stt,'installed',return_value=False):
            r=self.client.post('/api/voice/transcribe',content=b'audio',headers=self.headers|{'Content-Type':'audio/webm'})
            self.assertEqual(r.status_code,409)
        with patch.object(voice_api.local_stt,'installed',return_value=True):
            for content,mime,status in [(b'x','text/plain',415),(b'','audio/webm',400),(b'x'*(voice_api.MAX_AUDIO+1),'audio/webm',413)]:
                r=self.client.post('/api/voice/transcribe',content=content,headers=self.headers|{'Content-Type':mime})
                self.assertEqual(r.status_code,status)
    def test_unclear_speech_does_not_invent_transcript(self):
        with patch.object(voice_api.local_stt,'installed',return_value=True),patch.object(voice_api.local_stt,'transcribe',new_callable=AsyncMock) as transcribe:
            transcribe.return_value={'ok':False,'ly_do':'khong_nghe_ro'}
            r=self.client.post('/api/voice/transcribe',content=b'noise',headers=self.headers|{'Content-Type':'audio/webm'})
            self.assertEqual(r.json()['text'],'')
    def test_installed_no_download(self):
        with patch.object(voice_api.local_stt,'installed',return_value=True),patch.object(voice_api,'_install') as installer:
            r=self.client.post('/api/voice/install',json={},headers=self.headers)
            self.assertEqual(r.status_code,200)
            installer.assert_not_called()
