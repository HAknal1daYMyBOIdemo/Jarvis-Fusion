# Requires a separately installed Playwright and Chromium. Use an isolated FUSION_DATA_DIR.
# This test deletes notes in the server under test; never point it at a real user's vault.
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1440,'height':1000},device_scale_factor=1)
    errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto('http://127.0.0.1:8765')
    state=page.request.get('http://127.0.0.1:8765/api/state').json()
    for note in state['notes']:
        page.request.delete('http://127.0.0.1:8765/api/notes/'+note['id'],headers={'X-Fusion-Token':state['token']})
    page.reload()
    page.locator('[data-view=brain]').click()
    page.get_by_role('heading',name='Your memory, connected.').wait_for()
    samples=[('Daily rhythm','Personal','I prefer focused mornings. See [[Writing style]].'),('Writing style','Preferences','Concise, direct writing with examples.'),('Fusion assistant','Projects','Windows-first assistant with [[Local models]] and [[Memory system]].'),('Local models','Knowledge','Ollama runs models on my machine. Related to [[Privacy preferences]].'),('Memory system','Knowledge','Markdown notes preserve context across models. See [[Fusion assistant]].'),('Privacy preferences','Preferences','Ask before sharing personal context with cloud providers.'),('Learning plan','Personal','Study Python for [[Fusion assistant]].'),('Weekend project','Projects','Explore [[Local models]] and [[Learning plan]].')]
    for title,category,body in samples:
        page.get_by_role('button',name='+ New memory',exact=True).click()
        page.locator('#note-title').fill(title)
        page.locator('#note-category').select_option(category)
        page.locator('#note-body').fill(body)
        page.get_by_role('button',name='Save memory ↗').click()
        page.locator('#note-dialog').wait_for(state='hidden')
    page.wait_for_function("() => document.querySelector('#counts').textContent.startsWith('8 memories')")
    page.locator('#search').fill('Daily rhythm')
    assert page.locator('#memory-list button').count()==1
    page.locator('#memory-list button').click()
    assert page.locator('#note-title').input_value()=='Daily rhythm'
    page.locator('#note-body').fill('I prefer focused mornings. See [[Writing style]] and [[Learning plan]].')
    page.get_by_role('button',name='Save memory ↗').click()
    page.locator('#note-dialog').wait_for(state='hidden')
    page.locator('#search').fill('')
    page.locator('#provider').select_option('openai')
    assert page.locator('#cloud-choice').is_visible()
    assert not page.locator('#cloud-ok').is_checked()
    page.locator('#provider').select_option('ollama')
    page.screenshot(path='/workspace/work/fusion-memory-preview.png',full_page=True)
    page.locator('[data-view=library]').click()
    page.wait_for_function("() => document.querySelectorAll('.model-card').length===21")
    page.locator('#model-search').fill('embedding')
    assert page.locator('.model-card').count()==2
    page.locator('#model-search').fill('')
    page.screenshot(path='/workspace/work/fusion-models-preview.png',full_page=True)
    page.locator('[data-view=brain]').click()
    page.set_viewport_size({'width':390,'height':844})
    page.screenshot(path='/workspace/work/fusion-mobile-preview.png',full_page=True)
    assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth')
    assert not errors,errors
    browser.close()
    print('PASS: create/edit memory, graph search, provider toggle, 21 model cards, capability filter, desktop/mobile layout; no JS errors.')
