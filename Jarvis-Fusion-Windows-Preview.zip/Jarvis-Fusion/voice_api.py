"""Optional local speech, reusing the pinned Javis OS offline-ear implementation."""
import asyncio
from fastapi import APIRouter, HTTPException, Request
import local_stt
import winproc

router = APIRouter(prefix='/api/voice')
job = {'running':False, 'error':'', 'message':''}
_task = None
MAX_AUDIO = 8 * 1024 * 1024

def snapshot():
    return {'installed':local_stt.installed(), 'model':local_stt.MODEL,
            'size_hint':local_stt.SIZE_HINT, **job}

@router.get('/status')
def status():
    return snapshot()

async def _install():
    proc = None
    try:
        argv,cwd,env,timeout,_ = local_stt.install_command()
        # All paths/arguments come from the pinned local module, never the request.
        log_path = local_stt.ROOT/'install.log'
        with log_path.open('wb') as log:
            proc = await asyncio.create_subprocess_exec(*argv,cwd=cwd,env=env,
                stdout=log,stderr=log,stdin=asyncio.subprocess.DEVNULL,**winproc.kwargs_no_window())
            await asyncio.wait_for(proc.wait(),timeout)
        if proc.returncode or not local_stt.installed():
            raise RuntimeError('install failed')
        job['message']='Local speech is ready.'
    except BaseException as exc:
        if proc and proc.returncode is None:
            proc.kill()
            await proc.wait()
        job['error']='Speech setup failed. Check internet access and disk space; see data/javis-state/local-ear/install.log.'
        if isinstance(exc,asyncio.CancelledError): raise
    finally:
        job['running']=False

@router.post('/install')
async def install():
    global _task
    if local_stt.installed(): return snapshot()
    if not job['running']:
        job.update(running=True,error='',message='Downloading local Whisper and its dependencies. This can take several minutes.')
        _task=asyncio.create_task(_install())
    return snapshot()

@router.post('/transcribe')
async def transcribe(request: Request):
    if not local_stt.installed():
        raise HTTPException(409,'Install local speech in Voice settings first.')
    content_type=request.headers.get('content-type','').split(';')[0]
    extensions={'audio/webm':'.webm','audio/ogg':'.ogg','audio/mp4':'.m4a','audio/wav':'.wav'}
    if content_type not in extensions: raise HTTPException(415,'Unsupported audio format.')
    data=bytearray()
    async for chunk in request.stream():
        data.extend(chunk)
        if len(data)>MAX_AUDIO: raise HTTPException(413,'Audio clip is too large. Keep questions under 30 seconds.')
    if not data: raise HTTPException(400,'No microphone audio received.')
    result=await local_stt.transcribe(bytes(data),'question'+extensions[content_type],lang='en')
    if not result.get('ok'):
        if result.get('ly_do')=='khong_nghe_ro': return {'text':'','model':local_stt.MODEL}
        raise HTTPException(502,'Local transcription failed. Check Voice settings and try again.')
    return {'text':str(result.get('text',''))[:8000],'model':result.get('model','')}
