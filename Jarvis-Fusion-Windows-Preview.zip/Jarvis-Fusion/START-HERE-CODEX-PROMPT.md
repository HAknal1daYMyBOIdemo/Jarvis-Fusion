Continue Jarvis Fusion from this working Windows-oriented preview. Read READ-ME-FIRST.md,
AGENTS.md and DECISIONS.md. Reuse the pinned Javis memory and model-management modules and
OpenJarvis engines. Priorities: verify on Windows with real Ollama; implement safe vault import;
then integrate the existing Javis automatic memory-writing lifecycle and OpenJarvis agent tools.
Report major architecture decisions as they arise. Keep model-independent memory intact.
